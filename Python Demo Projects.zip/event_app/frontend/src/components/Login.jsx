import { Component } from "react";

class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            handleLoginSubmit : this.props.handleLoginSubmit,
            username : "",
            password : "",
        }        
    }

    handleChange = (e) => {
        let { name, value } = e.target;

        if (e.target.type === "checkbox") {
            value = e.target.checked;
        }

        this.setState({ [name]: value });
    };
    render() {
        return (
            <div>
                <input type="text" value={this.state.username} name='username' onChange={this.handleChange}/>
                <input type="text" value={this.state.password} name='password' onChange={this.handleChange}/>
                <input type="submit" onClick={() => {
                    this.state.handleLoginSubmit(this.state)
                }}/>
            </div>
        );
    }
}

export default Login;