from django import forms


class ValidationForm(forms.Form):
    name = forms.CharField(label='username', max_length=30, widget=forms.TextInput(attrs={
        'id': 'username',
        'class': 'raju',
        'data-validation': 'validate[required, custom[noSpecialCharacters], length[0,20]]'

    }))
