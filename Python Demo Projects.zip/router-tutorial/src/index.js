import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Invoices from './routes/invoices';
import Expenses from './routes/expenses';
import Invoice from './routes/invoice';

ReactDOM.render(
	<React.StrictMode>
		<BrowserRouter>
			<Routes>
				<Route path="/" element={<App />}>
					<Route path="expenses" element={<Expenses />}></Route>
					<Route path="invoices" element={<Invoices />}>
						<Route index
							element={
								<main style={{ padding: "1rem" }}>
									<p>Select an Invoice</p>
								</main>
							}></Route>
						<Route path=":invoiceId" element={<Invoice />}></Route>
					</Route>
					<Route path="*"
						element={
							<main style={{
								padding: '1rem'
							}}>
								<p>There's nothing these You might lost in space</p>
							</main>
						}
					></Route>
				</Route>

			</Routes>
		</BrowserRouter>
	</React.StrictMode>,
	document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
// clearn console
if (module.hot) {
	module.hot.accept() // already had this init code 

	module.hot.addStatusHandler(status => {
		if (status === 'prepare') console.clear()
	})
}