import logo from './logo.svg';
import './App.css';
import { Link, Outlet } from 'react-router-dom';

function App() {
  return (
    <div>
		<h1>Bookkeeper!</h1>
		<nav 
			style={{
				borderBottom: 'solid 2px',
				paddingBottom: '1rem'
			}}
		>
				<Link to='/invoices'>Invoice</Link> | {" "}
				<Link to='/expenses'>Expances</Link>
		</nav>
		<Outlet/>
    </div>
  );
}

export default App;
