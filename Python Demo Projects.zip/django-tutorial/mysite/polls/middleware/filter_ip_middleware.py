from django.core.exceptions import PermissionDenied


class FilterIPMiddleware(object):
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        self.process_request(request)
        response = self.get_response(request)
        return response

    # Check if the ip is allowed
    def process_request(self, request):
        allowed_ips = ['192.168.1.1', '123.123.123.123', '127.0.0.1']  # Authorized IP list

        ip = request.META.get('REMOTE_ADDR')  # Get users IP
        if ip in allowed_ips:
            raise PermissionDenied

        # If ip is allowed do nothing
        return request
