import { Link, NavLink, Outlet, useSearchParams } from "react-router-dom";
import { getInvoices } from "../data";
import QueryNavLink from "./Components/QueryNavLink";

function Invoices() {
    let invoices = getInvoices();
    let [searchParam, setSearchParam] = useSearchParams();
    return (
        <div style={{ display: "flex" }}>
            <nav style={{
                borderRight: "solid 1px",
                padding: "1rem"
            }}>
                <input value={searchParam.get('filter') || ''}
                    onChange={event => {
                        let filter = event.target.value;
                        if (filter) {
                            setSearchParam({ filter });
                        } else {
                            setSearchParam({});
                        }
                    }}></input>
                {
                    invoices.filter(invoice => {
                        let filter = searchParam.get('filter');
                        if (!filter) return true;
                        console.log(invoice.name)
                        let name = invoice.name.toLowerCase();
                        return name.startsWith(filter.toLowerCase());
                    }).map(invoice => (
                        <QueryNavLink


                            style={({ isActive }) => {
                                return {
                                    display: 'block',
                                    margin: '1rem 0 ',
                                    color: isActive ? 'red' : ''
                                }
                            }}
                            key={invoice.number}
                            to={`/invoices/${invoice.number}`}
                        >
                            {invoice.name}
                        </QueryNavLink>
                    ))
                }

            </nav>
            <Outlet />

        </div>
    );
}

export default Invoices;