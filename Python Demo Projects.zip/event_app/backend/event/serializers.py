import datetime
from datetime import timedelta

from dateutil import relativedelta
from django.contrib.auth.models import User
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
from rest_framework import serializers

from event.models import Event

days_code_arr = [
    relativedelta.MO(+1),
    relativedelta.TU(+1),
    relativedelta.WE(+1),
    relativedelta.TH(+1),
    relativedelta.FR(+1),
    relativedelta.SA(+1),
    relativedelta.SU(+1),
]


class EventSerializers(serializers.ModelSerializer):
    next_event = serializers.SerializerMethodField()

    class Meta:
        model = Event
        fields = [
            'id',
            'title',
            'start_date_time',
            'end_date_time',
            'duration',
            'venue',
            'repeat_period',
            'repeat_on',
            'next_event'
        ]

    def to_representation(self, instance):
        representation = super(EventSerializers, self).to_representation(instance)
        representation['start_date_time'] = instance.start_date_time.strftime('%d-%m-%Y %H:%M')
        representation['end_date_time'] = instance.end_date_time.strftime('%d-%m-%Y %H:%M')
        representation['duration'] = instance.duration.strftime('%H:%M')
        return representation

    def get_next_event(self, instance):

        next_event_date = ''

        today = datetime.datetime.today()
        repeat_on_arr = instance.repeat_on.split(',')

        next_event_date = None
        for repeat_on in repeat_on_arr:
            calculate_next_event_date = self.calculate_next_date(instance, int(repeat_on), today)

            if next_event_date is None:
                next_event_date = calculate_next_event_date

            if calculate_next_event_date < next_event_date:
                next_event_date = calculate_next_event_date

        return next_event_date.strftime('%d-%m-%Y')

    def calculate_next_date(self, instance, repeat_on, today):

        next_event_date = None

        if instance.repeat_period == 'daily':
            next_event_date = today + timedelta(days=1)

        if instance.repeat_period == 'weekly':
            next_event_date = today + relativedelta.relativedelta(weekday=days_code_arr[repeat_on], days=+1)

        if instance.repeat_period == 'monthly':

            if today.day >= repeat_on:
                months = 1
            else:
                months = 0

            next_event_date = today + relativedelta.relativedelta(months=months, day=repeat_on)

        return next_event_date


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        write_only_fields = ['password']
        fields = ['id', 'email', 'username', 'password']

    def create(self, validated_data):
        user = User.objects.create(
            username=validated_data['username'],
            email=validated_data['email'],
        )
        user.set_password(validated_data['password'])
        user.save()

        send_mail(
            'Welcome ',
            {
                'username': validated_data['username'],
            },
            [
                validated_data['email']
            ]
        )
        return user


def send_mail(subject, render_dict, recipients_arr):
    template = get_template('templates/email.html')
    filled_template = template.render(render_dict)
    email_multi_alternatives = EmailMultiAlternatives(subject, filled_template, 'mail@gmail.com', recipients_arr)
    email_multi_alternatives.attach_alternative(filled_template, 'text/html')
    email_multi_alternatives.send()
