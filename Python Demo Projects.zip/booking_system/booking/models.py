from django.db import models


# Create your models here.
class Tables(models.Model):
    objects = models.Manager()
    capacity = models.IntegerField()


class Booking(models.Model):
    objects = models.Manager()
    date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()
    no_of_people = models.IntegerField()
    table = models.ForeignKey(Tables, on_delete=models.CASCADE)
