import json
import threading
import time

import requests


def create_login_session(login_url):

    l_session = requests.Session()
    response = l_session.get(login_url)

    if response.status_code == 200:
        response_post = l_session.post(
            login_url,
            data={
                'auth[driver]': 'server',
                'auth[server]': '',
                'auth[username]': 'root',
                'auth[password]': 'mysqldba',
                'auth[db]': '',
                'auth[permanent]': '1',
            }
        )

        if response_post.status_code == 200:
            return l_session

    return None


def fetch_web_page_data(input_url):
    # Getting User page
    web_page_session_response = session.get(input_url)

    if web_page_session_response.status_code == 200:
        try:
            with open('test.html', 'w') as file:
                file.write(str(web_page_session_response.content))
        except Exception as e:
            print('got error in fetch_web_page_data', e)

    else:
        print(web_page_session_response.status_code, 'Code in fetch_web_page_data')


def fetch_api_data(api_url):
    api_session_response = session.get(api_url)

    if api_session_response.status_code == 200:
        try:
            with open('test.json', 'w') as file:
                file.write(json.dumps(json.loads(api_session_response.content)))
        except Exception as e:
            print('got error in fetch_api_data', e)
    else:
        print(api_session_response.status_code, 'Code in fetch_api_data')


def heart_beat(heart_beat_url):
    while True:
        session.get(heart_beat_url)
        time.sleep(10)
        print('ping...')


session = create_login_session('http://localhost/source.php')
if session is not None:

    # Starting HeartBeat
    t1 = threading.Thread(target=heart_beat, args=('http://localhost/source.php?username=root',))
    t1.start()

    while True:
        print('Pulling data...')
        fetch_web_page_data('http://localhost/source.php?username=root&db=catalet&select=device_types')
        # fetch_api_data(
        #     'http://localhost/projects/CRUSA_BackendAdmin/public/admin/building/building-loss-report-data'
        # )
        time.sleep(2 * 60)
