import axios from "axios";
import { Component } from "react";
import EventList from "./components/EventList";
import Nav from "./components/Nav";

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            is_logined: localStorage.getItem('access_token') !== null,
            event_list: []
        }
    }
    componentDidMount() {
        let access_token = localStorage.getItem('access_token');
        axios({
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${access_token}`
            },
            url: 'events/',
        }).then(response => {
            this.setState({
                event_list: response.data
            })
        })
    }
    handleLoginSubmit = (data) => {

        axios({
            method: "POST",
            url: 'token/',
            data: data
        }).then((response) => {
            localStorage.setItem('access_token', response.data.access)
            localStorage.setItem('refresh_token', response.data.refresh)

            this.setState({
                is_logined: true
            })

        }).catch(function (error) {
            if (error.response.status === 401) {
                alert('Invalid username and password');
            }
        })
    }
    handleLogout = () => {
        localStorage.removeItem('access_token');
        localStorage.removeItem('refresh_token');
        this.setState({
            is_logined: false
        })
    }
    render() {
        return (
            <div>
                <Nav
                    is_logined={this.state.is_logined}
                    handleLoginSubmit={this.handleLoginSubmit}
                    handleLogout={this.handleLogout}
                />
                {this.state.is_logined && this.state.event_list && <EventList event_list={this.state.event_list} />}
            </div>
        );
    }
}


export default App;
