from PIL import Image, ImageEnhance, ImageFilter
import pytesseract


def find_text_and_return(path):
    # Converting black and white
    img = Image.open(path)
    img = img.convert('RGB')
    pix = img.load()
    for y in range(img.size[1]):
        for x in range(img.size[0]):
            if pix[x, y][0] < 102 or pix[x, y][1] < 102 or pix[x, y][2] < 102:
                pix[x, y] = (0, 0, 0, 255)
            else:
                pix[x, y] = (255, 255, 255, 255)
    img.save('temp/temp.jpg')

    # Enhancing and extracting text

    im = Image.open("temp/temp.jpg")  # the second one
    im = im.filter(ImageFilter.MedianFilter())
    enhancer = ImageEnhance.Contrast(im)
    im = enhancer.enhance(2)
    im = im.convert('1')
    im.save('temp/temp2.jpg')
    text1 = pytesseract.image_to_string(Image.open('temp/temp2.jpg'))
    if len(text1) <= 2:
        print(text1)

        text1 = pytesseract.image_to_string(Image.open('temp/temp.jpg'))

    if len(text1.split('\n')) > 1:
        return text1
    return ''.join(text1.split('\n')[0]).replace(' ', '')


# print(find_text_and_return('input/captcha.gif'))
# print(find_text_and_return('input/new_cap.gif'))
# print(find_text_and_return('input/irct.gif').split('Typeintheboxbelowso')[1])
# print(find_text_and_return('input/irct2.gif').split('Typeintheboxbelows')[1])
# print(find_text_and_return('input/adhar1.gif'))
print(find_text_and_return('input/adhar2.gif'))

# Captcha List https://gist.github.com/christianroman/5679049
# Future References :
# https://medium.com/@ageitgey/how-to-break-a-captcha-system-in-15-minutes-with-machine-learning-dbebb035a710
