import { Component } from "react";

class EventList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            event_list: this.props.event_list
        };
    }
    
    
    state = {}
    render() {
        let event_list = this.props.event_list;
        let event_list_render = event_list.map((one_event) => (
            <div  key={one_event.id}>
                <ul>
                    <li>id: {one_event.id}</li>
                    <li>title: {one_event.title}</li>
                    <li>venue: {one_event.venue}</li>
                    <li>duration: {one_event.duration}</li>
                    <li>start_date_time: {one_event.start_date_time}</li>
                    <li>end_date_time: {one_event.end_date_time}</li>
                    <li>next_event: {one_event.next_event}</li>
                    <li>repeat_on: {one_event.repeat_on}</li>
                    <li>repeat_period: {one_event.repeat_period}</li>
                </ul>
                <hr></hr>
            </div>
        ));
        return (
            <div>
                {event_list_render}
            </div>
        );
    }
}

export default EventList;