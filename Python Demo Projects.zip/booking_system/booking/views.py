import datetime

from django.shortcuts import render, redirect
from django.db import models

# Create your views here.
from django.urls import reverse

from .models import Tables, Booking


def index(request):
    return render(request, 'templates/index.html')


def check_available_table(request):
    date = request.GET['date']
    time = request.GET['time']
    no_of_people = request.GET['no_of_people']

    start_time = (datetime.datetime.strptime(time, '%H:%M').time())
    end_time = (datetime.datetime.strptime(time, '%H:%M') + datetime.timedelta(hours=1)).time()

    # Finding tables that already booked at that time frame
    bookings = Booking.objects.filter(date=date, start_time__lt=end_time, end_time__gt=start_time)

    # Getting table id which are already registered
    exclude_table_ids = []
    for booking in bookings:
        exclude_table_ids.append(booking.table_id)

    tables = Tables.objects.filter(capacity__gte=no_of_people).exclude(id__in=exclude_table_ids)
    return render(request, 'templates/booking.html', {
        'tables': tables,
        'date': date,
        'time': time,
        'no_of_people': no_of_people,
    })


def save_booking_details(request):
    date = request.GET['date']
    time = request.GET['time']
    no_of_people = request.GET['no_of_people']
    table_id = request.GET['table_id']

    start_time = (datetime.datetime.strptime(time, '%H:%M').time())
    end_time = (datetime.datetime.strptime(time, '%H:%M') + datetime.timedelta(hours=1)).time()

    booking = Booking(
        date=date,
        start_time=start_time,
        end_time=end_time,
        no_of_people=no_of_people,
        table_id=table_id,
    )

    booking.save()
    return redirect(reverse('templates.index'), kwargs={'success': True})
