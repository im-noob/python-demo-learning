from django.contrib.auth import get_user_model
from rest_framework import viewsets, permissions
from rest_framework.generics import CreateAPIView
from rest_framework.viewsets import GenericViewSet

from event.models import Event
from event.serializers import EventSerializers, UserSerializer


class EventViewSet(viewsets.ModelViewSet):
    serializer_class = EventSerializers

    def get_queryset(self):
        return Event.objects.all()


class UserViewSet(CreateAPIView, GenericViewSet):
    model = get_user_model()
    permission_classes = [
        permissions.AllowAny,
    ]
    serializer_class = UserSerializer
