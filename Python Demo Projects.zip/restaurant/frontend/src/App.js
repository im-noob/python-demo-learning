import { Component } from "react";
import LoginForms from "./components/LoginForm";
import Nav from "./components/Nav";
import SignupForm from "./components/SignupForm";

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            displayed_form: '',
            logged_in: localStorage.getItem('token') ? true : false,
            username: '',
            menus: []
        };
    }
    componentDidMount() {
        if (this.state.logged_in) {
            fetch('http://127.0.0.1:8000/api/menu/', {
                headers: {
                    Authorization: `token ${localStorage.getItem('token')}`
                }
            }).then(response => response.json())
                .then(json => {
                    console.log(json);
                    this.setState({ menus: json })
                });

            this.setState({ username: 'json.username' })
        }
    }
    handle_login = (e, data) => {
        e.preventDefault();
        fetch('http://127.0.0.1:8000/api/get-auth-token/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(data)
        })
          .then(res => res.json())
          .then(json => {
            localStorage.setItem('token', json.token);
            this.setState({
              logged_in: true,
              displayed_form: '',
              username: 'raju'
            });
          });
      };
    handle_signup = (e, data) => {
        e.preventDefault();
        fetch('http://localhost:8000/core/users/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
            .then(res => res.json())
            .then(json => {
                localStorage.setItem('token', json.token);
                this.setState({
                    logged_in: true,
                    displayed_form: '',
                    username: json.username
                });
            });
    };

    handle_logout = () => {
        localStorage.removeItem('token');
        this.setState({ logged_in: false, username: '' });
    };

    display_form = form => {
        this.setState({
            displayed_form: form
        });
    };
    renderMenu = () =>{
        let menus = this.state.menus;
        return menus.map((item) => (
            <li key={item.id}>
                <ul>
                    <li>Name : {item.name}</li>
                    <li>Description : {item.description}</li>
                    <li>Created At : {item.created_at}</li>
                    <li>Updated At : {item.updated_at}</li>
                    <hr />
                </ul>
            </li>
        ));
    }
    render() {
        let form;
        switch (this.state.displayed_form) {
            case 'login':
                form = <LoginForms handle_login={this.handle_login} />;
                break;
            case 'signup':
                form = <SignupForm handle_signup={this.handle_signup} />;
                break;
            default:
                form = null;
        }
        return (
            <div className="App">
                <Nav
                    logged_in={this.state.logged_in}
                    display_form={this.display_form}
                    handle_logout={this.handle_logout}
                />
                {form}
                <h3>
                    <ol>
                        {this.state.logged_in && this.renderMenu()}
                    </ol>
                </h3>
            </div>
        );
    }
}

export default App;

