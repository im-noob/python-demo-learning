import json
import threading
import time

import requests


def create_login_session():
    login_url = 'http://localhost/projects/CRUSA_BackendAdmin/public/login'

    l_session = requests.Session()
    response = l_session.get(login_url)

    if response.status_code == 200:
        content = str(response.content)
        if 'csrf-token' in content:
            crsf_part = str(content).split('csrf-token" content="')[1]
            crsf_token = crsf_part.split('">')[0]

            response_post = l_session.post(
                login_url,
                data={
                    '_token': crsf_token,
                    'email': 'admin@admin.com',
                    'password': 'Calgary2021!!'
                }
            )

            if response_post.status_code == 200:
                return l_session

    return None


def fetch_building_details():
    # Getting User page
    building_list = session.get('http://localhost/projects/CRUSA_BackendAdmin/public/admin/building')

    if building_list.status_code == 200:
        try:
            with open('test.html', 'w') as file:
                file.write(str(building_list.content))
        except Exception as e:
            print('got error in fetch_building_details', e)

    else:
        print(building_list.status_code, 'Code in fetch_building_details')


def fetch_api_loss_report():
    report_url = 'http://localhost/projects/CRUSA_BackendAdmin/public/admin/building/building-loss-report-data'
    loss_session = session.get(report_url)

    if loss_session.status_code == 200:
        try:
            with open('test.json', 'w') as file:
                file.write(json.dumps(json.loads(loss_session.content)))
        except Exception as e:
            print('got error in fetch_api_loss_report', e)
    else:
        print(loss_session.status_code, 'Code in fetch_api_loss_report')


def heart_beat():
    while True:
        session.get('http://localhost/projects/CRUSA_BackendAdmin/public/admin')
        time.sleep(10)
        print('ping...')


session = create_login_session()
if session is not None:

    # Starting HeartBeat
    t1 = threading.Thread(target=heart_beat)
    t1.start()

    while True:
        print('Pulling data...')
        fetch_building_details()
        fetch_api_loss_report()
        time.sleep(2*60)
