from django.db import models


# Create your models here.
class Event(models.Model):
    objects = models.Manager()

    title = models.CharField(max_length=255)
    start_date_time = models.DateTimeField()
    end_date_time = models.DateTimeField()
    duration = models.TimeField()
    venue = models.CharField(max_length=255)
    repeat_period = models.CharField(max_length=255)
    repeat_on = models.CharField(max_length=255, null=True)

    def __str__(self):
        return self.title
