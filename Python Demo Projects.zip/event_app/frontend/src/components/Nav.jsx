import { Component } from "react";
import Login from "./Login";
import Register from "./Register";

class Nav extends Component {
    constructor(props) {
        super(props);
        this.state = {
            is_logined: this.props.is_logined,
            display_form: '',
        }
    }

    showForm = (form_type) => {
        this.setState({
            'display_form': form_type,
        })
    }


    render() {
        let form = '';

        if (this.state.display_form === 'login') {
            form = <Login handleLoginSubmit={this.props.handleLoginSubmit} />
        } else if (this.state.display_form === 'register') {
            form = <Register />
        } else {
            form = 'No'
        }

        const login_nav = (
            <ul>
                <li onClick={() => { this.showForm('login') }}>Login</li>
                <li onClick={() => { this.showForm('register') }}>Register</li>
            </ul>
        );
        const logout_nav = (
            <ul>
                <li onClick={this.props.handleLogout}>Logout</li>
            </ul>
        );
        return (
            <div>
                {this.props.is_logined ? logout_nav : login_nav}
                <hr></hr>

                {this.props.is_logined === false && form}

            </div>
        );
    }
}

export default Nav;