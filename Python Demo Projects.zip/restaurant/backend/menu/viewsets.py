from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated

from menu.models import Menu
from menu.serializers import MenuSerializer


class MenuViewSet(viewsets.ModelViewSet):

    permission_classes = (IsAuthenticated,)
    serializer_class = MenuSerializer

    def get_queryset(self):
        return Menu.objects.all()
