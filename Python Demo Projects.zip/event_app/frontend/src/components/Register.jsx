import { Component } from "react";

class Register extends Component {
    constructor(props) {
        super(props);
    }
    state = {

    }
    render() {
        return (
            <div>
                Registser
            </div>
        );
    }
}

export default Register;