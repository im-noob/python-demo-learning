from django.contrib import admin

# Register your models here.
admin.site.register([Events, RegisteredUser])
