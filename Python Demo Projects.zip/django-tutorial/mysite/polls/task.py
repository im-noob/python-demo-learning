from django_q.models import Schedule
from django_q.tasks import schedule

schedule(
    'polls.views.send_mail',
    'Good Morning',
    '',
    ('mail_to_@gmail.com',),
    schedule_type=Schedule.ONCE
)
