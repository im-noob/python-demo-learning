from rest_framework import serializers

from menu.models import Menu


class MenuSerializer(serializers.ModelSerializer):
    class Meta:
        model = Menu
        fields = ['id', 'name', 'description', 'price', 'created_at', 'updated_at']

    def to_representation(self, instance):
        representation = super(MenuSerializer, self).to_representation(instance)
        representation['created_at'] = instance.created_at.strftime('%d-%m-%Y %H:%M')
        representation['updated_at'] = instance.updated_at.strftime('%d-%m-%y %H:%M')
        return representation

